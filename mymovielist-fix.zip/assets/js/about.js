$(document).ready(function(){

  $('.about-head').animate({
    'top' : '10px',
    'opacity' :  '1'
  }, 1500)

  $('.about-body').animate({
    'top' : '70px',
    'opacity' : '1'
  }, 1500)

})