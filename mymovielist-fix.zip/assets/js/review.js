$(document).ready(function(){

  $(".head-main h3 ").animate({
    "top": "0px","opacity" :"1","right":"20px",
  },"slow")
  $(".head-main h3 ").animate({
    "top": "0px","opacity" :"1","left":"20px"
  },"slow")

})